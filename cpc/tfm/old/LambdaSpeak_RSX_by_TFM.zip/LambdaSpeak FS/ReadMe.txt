
Dear friends of the CPC and the LambdaSpeak FutureSoft
------------------------------------------------------

There are at least two variants of the MP3 player (they look identical though)

The command |MP3PLAYF works either with a parameter set to 0 or to 2.
Therefore you get two vesions of the ROM and of the 'LFS_1_RSX_ROM_Lisa_MP3-....DSK' file.

Just see what works for you :-)

Greetings, 
TFM


